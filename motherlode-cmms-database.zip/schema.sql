
-- Create technicians
CREATE TABLE IF NOT EXISTS technicians (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin', 'tech')),
    active BOOLEAN DEFAULT TRUE
);

-- Daily Reports
CREATE TABLE IF NOT EXISTS daily_reports (
    id SERIAL PRIMARY KEY,
    technician_id INTEGER REFERENCES technicians(id),
    shift TEXT NOT NULL,
    report_text TEXT NOT NULL,
    report_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Preventive Maintenance Tasks
CREATE TABLE IF NOT EXISTS pm_tasks (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT,
    assigned_to INTEGER REFERENCES technicians(id),
    due_date DATE,
    completed BOOLEAN DEFAULT FALSE,
    completed_date DATE
);

-- Inventory
CREATE TABLE IF NOT EXISTS inventory (
    id SERIAL PRIMARY KEY,
    part_name TEXT NOT NULL,
    stock_quantity INTEGER NOT NULL,
    reorder_threshold INTEGER NOT NULL,
    unit TEXT DEFAULT 'pcs'
);

-- Reorder Requests
CREATE TABLE IF NOT EXISTS reorder_requests (
    id SERIAL PRIMARY KEY,
    inventory_id INTEGER REFERENCES inventory(id),
    requested_by INTEGER REFERENCES technicians(id),
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'denied')),
    requested_date DATE DEFAULT CURRENT_DATE,
    fulfilled_date DATE
);
