
-- Add Admin and Tech
INSERT INTO technicians (name, email, password_hash, role) VALUES
('Admin User', 'admin@motherlode.com', '$2a$10$eW5JLPLFZLj6vJYIFZfQmeQdyVmj4pq4LQKsmSyBr9NwhgG2KqU.6', 'admin'), -- password: admin123
('Tech One', 'tech@motherlode.com', '$2a$10$Vv/jzAMzMj4Uk12zL1chBeN/McFZzUvOEv05GIVJXXkGo3Ru0r3ny', 'tech'); -- password: tech123

-- Sample Inventory
INSERT INTO inventory (part_name, stock_quantity, reorder_threshold, unit) VALUES
('Air Filter', 10, 5, 'pcs'),
('Oil', 20, 10, 'liters');

-- Sample PM Task
INSERT INTO pm_tasks (title, description, assigned_to, due_date) VALUES
('Change Air Filter', 'Replace every 3 months', 2, CURRENT_DATE + INTERVAL '7 days');
